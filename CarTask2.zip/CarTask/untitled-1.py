from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_wtf import FlaskForm
from wtforms import StringField, DateField, SubmitField, SelectField
from wtforms.validators import DataRequired
import pandas as pd
import plotly.express as px
from flask_session import Session
from flask import jsonify
from datetime import datetime


app = Flask(__name__)

app.config['SECRET_KEY'] = '33242d1f9d3fa6208f1b5c3ad491d15a'
app.config['SESSION_TYPE'] = 'filesystem'
SESSION_TYPE = 'redis'
Session(app)

class UploadForm(FlaskForm):
    file = StringField('File', validators=[DataRequired()])
    vehicle = StringField('Vehicle')
    date = DateField('Date')
    submit = SubmitField('Upload')
    
class CarAndDateForm(FlaskForm):
    
    vehicle = SelectField('Vehicle', validators=[DataRequired()], choices=[])
    date = SelectField('Date', validators=[DataRequired()], choices=[])
    submit = SubmitField('select')
    

@app.route('/', methods=['GET', 'POST'])
def index():
    form = UploadForm()
    if form.validate_on_submit() :
        flash('File uploaded successfully!')
        print("bandile successfully")
        return redirect(url_for('results'))

    return render_template('upload.html', form=form)

@app.route('/upload', methods=['POST'])
def upload():
    form = UploadForm()

    if form.validate_on_submit():
        try:
            file = request.files['file']
            data = pd.read_excel(file)
            
            # Validate vehicle and date
            vehicle = form.vehicle.data
            date = form.date.data
            
            dict_obj = data.to_dict('list')
            session['uploaded_data'] = dict_obj
            print("Inssssssssssssssiiiiiiiiiiiiiiiiiiiiiiidddddddddddddddddeeeeeeeeee")
            session['test'] = 'yes I am working'
            

            return redirect(url_for('results'))

        except Exception as e:
            flash(f"Error processing the file: {e}")
            return redirect(url_for('index'))

    return redirect(url_for('index'))

@app.route('/results', methods=['GET', 'POST'])
def results():
    if 'uploaded_data' not in session:
        flash('No data available. Please upload a file.')
        return redirect(url_for('index'))
    
    dict_obj = session['uploaded_data']
    data = pd.DataFrame(dict_obj)
    

    form = CarAndDateForm()
    cars = data.VEHICLE.unique()
    print(type(cars))
    form.vehicle.choices = cars.tolist()
    
 
    # if True:
    #     print(data)
    #     # Process the selected vehicle and date
    #     selected_vehicle = form.vehicle.data
    #     selected_date = form.date.data
    #     fig = px.scatter_mapbox(data, lat='X', lon='Y', hover_name='VEHICLE')
    #     plot_div = fig.to_html(full_html=False)

    #     # Display a data table
    #     table_html = data.to_html(classes='table table-striped')

    #     # Render the results page
    #     return render_template('result.html', plot_div=plot_div, table_html=table_html)

    #     # Perform computations or display results based on the selected vehicle and date
    #     # For example, compute averages, generate plots, etc.

    #     flash(f"Results for {selected_vehicle} on {selected_date}")
    #     return redirect(url_for('results'))
    table_html = data.head(5000).to_html(classes='table table-striped')
    print(cars)
    return render_template('result.html', form=form, data=data,table_html=table_html)

@app.route('/get_dates', methods=['POST'])
def get_dates():
    #selected_vehicle = request.json.get('selected_vehicle')
    dict_obj = session['uploaded_data']
    data = pd.DataFrame(dict_obj)
    print("Yes Method called and is in here")
    dates = data.loc[data['VEHICLE'] == request.json.get('selected_vehicle')]
    #dates = dates['GPSDateTime']
    for ind in dates.index:
        dates['GPSDateTime'][ind] = dates['GPSDateTime'][ind].date()
    
    dates2 = dates.GPSDateTime.unique()
    print(dates2)
    return jsonify({'dates': dates2.tolist()})

if __name__ == '__main__':
    app.run(debug=True)
