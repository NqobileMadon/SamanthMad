from flask import Flask, render_template, request, redirect, url_for, flash
import pandas as pd
import plotly.express as px
from flask_wtf import FlaskForm
from wtforms import StringField, DateField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

class UploadForm(FlaskForm):
    file = StringField('File', validators=[DataRequired()])
    vehicle = StringField('Vehicle', validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()])
    submit = SubmitField('Upload')

@app.route('/', methods=['GET', 'POST'])
def index():
    form = UploadForm()
    if form.validate_on_submit():
        flash('File uploaded successfully!')
        return redirect(url_for('results'))

    return render_template('upload.html', form=form)

@app.route('/upload', methods=['POST'])
def upload():
    form = UploadForm()
    if 'file' not in request.files:
        return "No file part"

    file = request.files['file']

    if file.filename == '':
        return "No selected file"
    if form.validate_on_submit():
        try:
            file = request.files['file']
            data = pd.read_csv(file)

            # Validate vehicle and date
            vehicle = form.vehicle.data
            date = form.date.data

            if vehicle not in data['vehicle'].unique():
                flash('Invalid vehicle selection')
                return redirect(url_for('index'))

            if date not in data['date'].unique():
                flash('Invalid date selection')
                return redirect(url_for('index'))

            # Continue with the rest of the logic (e.g., store data in session, database, etc.)
            return redirect(url_for('results'))

        except Exception as e:
            flash(f"Error processing the file: {e}")
            return redirect(url_for('index'))

    return redirect(url_for('index'))

    try:
        # Read the uploaded data
        data = pd.read_excel(file)
        fig = px.scatter_mapbox(data, lat='X', lon='Y', hover_name='VEHICLE')
        plot_div = fig.to_html(full_html=False)
        table_html = data.to_html(classes='table table-striped')
        
        # Continue with the rest of the logic (e.g., store data in session, database, etc.)

        # Redirect to the results page
        #return redirect(url_for('results'))
        return render_template('result.html', plot_div=plot_div, table_html=table_html)

    except Exception as e:
        return f"Error processing the file: {e}"

@app.route('/results')
def results():
    # Retrieve data from session, database, or any other storage
    # Perform additional processing and calculations if needed

    # Render the results page
    return render_template('result.html')

if __name__ == '__main__':
    app.run(debug=True)